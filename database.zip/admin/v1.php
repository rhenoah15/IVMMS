<?php
include('../auth.php.');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>IVMMS: Management and Monitoring System of Immunization Vaccine in the Municipality of Mabinis</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/maruti-style.css" />
<link rel="stylesheet" href="css/maruti-media.css" class="skin-color" />
</head>
<body>

<div id="header" style="background-color:#ffffe0">
  
  <center><h3 style="color:#000;margin-top:10px">IVMMS: Management and Monitoring System of Immunization Vaccine in the Municipality of Mabinis</h1>
</div>
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">

  </ul>
</div>

<div id="sidebar" style="background-color:#CCCC00">
<a href="#" class="visible-phone">
<i class="icon icon-home"></i> Menu</a>
<ul>
    <li class="active"><a href="index.php"> <span style="color:#000">User Management</span></a> </li>
    <!-- <li class="active"><a href="schedule.php"> <span style="color:#000">Schedule</span></a> </li> -->
   <li class="active"><a href="dashboard.php"> <span style="color:#000">Dashboard</span></a> </li>
	
	
    <li><a href="../logout.php"><span style="color:#000">Logout</span></a></li>
    
  </ul>
</div>
   
            
<script >
	(function(document) {
	'use strict';

	var LightTableFilter = (function(Arr) {

		var _input;

		function _onInputEvent(e) {
			_input = e.target;
			var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
			var x = $('#data-table tbody tr:visible').length;
			document.getElementById("box").innerHTML = 'Number of Prisoner: '+x;
					
				});
			});
			
			
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
			
			
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
			
		};
		
			
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			
			LightTableFilter.init();
			
		}
	});
})(document);
//# sourceURL=pen.js
</script>	
<div id="content">
  <div id="content-header">
    
  </div>
  <div class="container-fluid">
    
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-content">
          <div class="row-fluid">
				<!-- s -->
					<script>
							
							function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
							</script>
							<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #CCCC00;
  color: #000;
}
input[type=text {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=button],input[type=submit] {
  width: 200px;
  background-color: #CCCC00;
  color: #000;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
	<?php						
include('../connect.php');
$resultpot = mysql_query("SELECT * FROM member WHERE status = 'Pending' ORDER BY idnumber ASC");
$countpot=mysql_num_rows($resultpot);
?>
		
		<?php
		$idnumber = $_GET['id'];
include('../connect.php');
if(isset($_POST['submit'])){ 
$vaccine = $_POST['vaccine'];
$date = $_POST['date'];
$dose = $_POST['dose'];
$time = $_POST['time'];
$save1=mysql_query("INSERT INTO record (vaccine,date,time,idnumber,dose) VALUES ('$vaccine','$date','$time','$idnumber','$dose')");

echo "<script type=\"text/javascript\">window.alert('Vaccination record has been added');window.location.href = 'v1.php?id=".$idnumber."';</script>"; 
}    
?>
		  <form action="#" method="POST">
		  <h3 style="margin:0px">Add Vaccination Record</h2>
			Vaccine:<br>
			<select name="vaccine" class="email" required>
								<option></option>
<option>BCG (Bacille-Calmette-Guerin)</option>
<option>Hepatitis B</option>
<option>Pentavalent vaccine</option>
<option>Polio (Oral Polio Vaccine o OPV)</option>
<option>Inactivated polio vaccine</option>
<option>Pneumococcal conjugate vaccine o PCV</option>
<option>Measles, Mumps, Rubella o MMR vaccine</option>
								
</select>
	<br>
			Dose:<br>
			<select name="dose" class="email" required>
								<option></option>
<option>First Dose</option>
<option>Second Dose</option>
								
</select>
	<br>
	Date:<br>
	<input type="date" name="date"><br>
	Time:<br>
	<input type="time" name="time">
	<br>
	<input type="submit" name="submit" value="Add Vaccination Record">
</form>
		  <br><br>
							<center>
								<br>
								<div class="datagrid">
								
						<table width="100%" border="1" style="border-collapse:collapse;padding:5px" class="tftable order-table table bluetext" id="customers">
							<thead>
							<tr>
								<th><b><center>Vaccine</th>
								<th><b><center>Dose</th>
								<th><b><center>Date</th>
								
								<th><b><center>Time</th>
								</tr>
							</thead>
							<tbody>
		
			<?php
include('../connect.php');

$result = mysql_query("SELECT * FROM record  WHERE idnumber = '$idnumber'");
while($row = mysql_fetch_array($result))
{
	$time = $row['time'];
	$time =  date('h:i A ', strtotime($time));
			echo '<tr>';
			echo '<td valign="top">&nbsp;'.$row['vaccine'].'</td>';
			echo '<td valign="top">&nbsp;'.$row['dose'].'</td>';
			
			echo '<td valign="top">&nbsp;'.$row['date'].'</td>';
			echo '<td valign="top">&nbsp;'.$time.'</td>';
			echo '</tr>';
}
?>
		
		</tbody>
							
						</table>
						</div>
		  
		  
		  <div id="printme" style="display:none">
		  	<div class="datagrid">
								
						<table width="100%" border="1" style="border-collapse:collapse;padding:5px" class="tftable order-table table bluetext">
							<thead>
							<tr>
								<th><b><center>Name</th>
								<th><b><center>Family Number</th>
								<th><b><center>Sitio</th>
								<th><b><center>Address</th>
								<th><b><center>Contact Number</th>
								</tr>
							</thead>
							<tbody>
		
			<?php
include('../connect.php');

$result = mysql_query("SELECT * FROM member  WHERE status = 'Approved'  ORDER BY idnumber ASC");
while($row = mysql_fetch_array($result))
{
			echo '<tr>';
			echo '<td valign="top">&nbsp;'.$row['lname'].', '.$row["fname"].' '.$row["mname"].'</td>';
			echo '<td valign="top">&nbsp;'.$row['idnumber'].'</td>';
			echo '<td valign="top">&nbsp;'.$row['sitio'].'</td>';
			echo '<td valign="top">&nbsp;'.$row['address'].'</td>';
			echo '<td valign="top">&nbsp;'.$row['mobile'].'</td>';
			echo '</tr>';
}
?>
		
		</tbody>
							
						</table>
						</div>
				
				<!-- e -->
          </div>
        </div>
      </div>
    </div>
    <hr>
  </div>
</div>
</div>
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> 2021 - Web Based Fire Detection System for BFP Lemery with SMS Alerts</div>
</div>
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/maruti.js"></script> 
<script src="js/maruti.dashboard.js"></script> 
<script src="js/maruti.chat.js"></script> 
 

<script type="text/javascript">
  function goPage (newURL) {

      if (newURL != "") {
      
          if (newURL == "-" ) {
              resetMenu();            
          } 
          else {  
            document.location.href = newURL;
          }
      }
  }

function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
